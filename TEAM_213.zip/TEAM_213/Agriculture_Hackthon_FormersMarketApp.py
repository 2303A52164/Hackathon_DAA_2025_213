import tkinter as tk
from tkinter import messagebox

products = []
transactions = []

def list_produce():
    name = entry_product_name.get().strip()
    price = entry_product_price.get().strip()

    if not name or not price:
        messagebox.showwarning("Missing Information", "Please enter both the name and price.")
        return

    try:
        price = float(price)
    except ValueError:
        messagebox.showwarning("Invalid Price", "Enter a valid number for price.")
        return

    products.append({'name': name, 'price': price})
    update_product_list()
    entry_product_name.delete(0, tk.END)
    entry_product_price.delete(0, tk.END)

def update_product_list():
    product_listbox.delete(0, tk.END)
    for i, product in enumerate(products):
        product_listbox.insert(tk.END, f"{i+1}. {product['name']} - ₹{product['price']} per kg")

def buy_product():
    selected = product_listbox.curselection()
    if not selected:
        messagebox.showinfo("Select Product", "Please select a product to buy.")
        return

    index = selected[0]
    product = products[index]

    try:
        quantity = float(entry_quantity.get())
        offer_price = float(entry_offer_price.get())
    except ValueError:
        messagebox.showwarning("Invalid Input", "Enter valid numbers for quantity and price.")
        return

    total = quantity * offer_price
    confirm = messagebox.askyesno("Confirm", f"Buy {quantity} kg of {product['name']} at ₹{offer_price}/kg?\nTotal: ₹{total}")
    
    if confirm:
        transactions.append({
            'name': product['name'],
            'quantity': quantity,
            'offer': offer_price,
            'total': total
        })
        messagebox.showinfo("Success", f"Purchased {quantity} kg of {product['name']} for ₹{total}.")
        entry_quantity.delete(0, tk.END)
        entry_offer_price.delete(0, tk.END)

def manage_transactions():
    if not transactions:
        messagebox.showinfo("No Transactions", "No transactions available to manage.")
        return

    manage_window = tk.Toplevel(root)
    manage_window.title("Manage Transactions")
    manage_window.geometry("400x300")
    
    lb = tk.Listbox(manage_window, width=50)
    lb.pack(pady=10)

    for i, t in enumerate(transactions):
        lb.insert(tk.END, f"{i+1}. {t['name']} - {t['quantity']}kg at ₹{t['offer']} (₹{t['total']})")

    def delete_transaction():
        selected = lb.curselection()
        if not selected:
            return
        index = selected[0]
        confirm = messagebox.askyesno("Delete", "Are you sure you want to delete this transaction?")
        if confirm:
            transactions.pop(index)
            lb.delete(index)

    btn_delete = tk.Button(manage_window, text="❌ Delete Selected", command=delete_transaction, bg="red", fg="white")
    btn_delete.pack(pady=5)

# Main GUI setup
root = tk.Tk()
root.title("Mobile App for Direct Market Access for Farmers")
root.geometry("600x650")
root.configure(bg="white")

# Title banner
title_frame = tk.Frame(root, bg="#6fcf97", height=60)
title_frame.pack(fill="x")
title_label = tk.Label(title_frame, text="🌽 Mobile App for Direct Market Access for Farmers 🌽", font=("Helvetica", 18, "bold"), bg="#6fcf97", fg="white")
title_label.pack(pady=10)

main_frame = tk.Frame(root, bg="white")
main_frame.pack(pady=10)

# Farmer Section
farmer_frame = tk.LabelFrame(main_frame, text="👨‍🌾 Farmer: List Produce", font=("Arial", 12, "bold"), bg="white", bd=2, relief="solid")
farmer_frame.grid(row=0, column=0, columnspan=2, padx=10, pady=8, sticky="ew")

tk.Label(farmer_frame, text="Product Name:", bg="white").grid(row=1, column=0, sticky='e')
entry_product_name = tk.Entry(farmer_frame, width=30)
entry_product_name.grid(row=1, column=1, padx=5, pady=2)

tk.Label(farmer_frame, text="Price per kg (₹):", bg="white").grid(row=2, column=0, sticky='e')
entry_product_price = tk.Entry(farmer_frame, width=30)
entry_product_price.grid(row=2, column=1, padx=5, pady=2)

tk.Button(farmer_frame, text="➕ List Produce", command=list_produce, width=25, bg="#27ae60", fg="white").grid(row=3, column=0, columnspan=2, pady=6)

# Product Listings
tk.Label(main_frame, text="🛒 Market Listings", font=("Arial", 12, "bold"), bg="white").grid(row=1, column=0, columnspan=2, pady=6)
product_listbox = tk.Listbox(main_frame, width=50)
product_listbox.grid(row=2, column=0, columnspan=2, padx=10, pady=5)

# Buyer Section
buyer_frame = tk.LabelFrame(main_frame, text="🧑‍🌾 Buyer: View & Negotiate", font=("Arial", 12, "bold"), bg="white", bd=2, relief="solid")
buyer_frame.grid(row=3, column=0, columnspan=2, padx=10, pady=8, sticky="ew")

tk.Label(buyer_frame, text="Quantity (kg):", bg="white").grid(row=4, column=0, sticky='e')
entry_quantity = tk.Entry(buyer_frame, width=30)
entry_quantity.grid(row=4, column=1, padx=5, pady=2)

tk.Label(buyer_frame, text="Your Offer Price (₹/kg):", bg="white").grid(row=5, column=0, sticky='e')
entry_offer_price = tk.Entry(buyer_frame, width=30)
entry_offer_price.grid(row=5, column=1, padx=5, pady=2)

tk.Button(buyer_frame, text="💰 Negotiate", command=buy_product, width=25, bg="#2980b9", fg="white").grid(row=6, column=0, columnspan=2, pady=6)

# Manage Transactions Button
tk.Button(main_frame, text="🧾 Manage Transactions", command=manage_transactions, width=25, bg="#8e44ad", fg="white").grid(row=4, column=0, columnspan=2, pady=10)

root.mainloop()
